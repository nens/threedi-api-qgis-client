class SchematisationError(Exception):
    pass


class TemplateValidationError(Exception):
    pass


class TemplateValidationTimeoutError(Exception):
    pass
